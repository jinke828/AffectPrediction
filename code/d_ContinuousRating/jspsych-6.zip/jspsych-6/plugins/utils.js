const VERSION = 1.0;

const SLIDE_MIN = 1;
const SLIDE_MAX = 25;
const SLIDE_BIG_STEP = 5;
const SLIDE_START = 13;
const SLIDE_WIDTH = 650;
const SLIDE_LABELS  = ['<h4>Not engaging at all</h4>', '|','|', '|', '|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','|','<h4>Completely engaging</h4>']

function unbindSliderEvents(sliderId){
  // need to remove the event handler
  // or it lasts into the next trial
  $(document).off('change', sliderId);
  $(document).unbind('keydown');
}

function sliderOnFinish(sliderId){
  unbindSliderEvents(sliderId);
};

function sliderOnLoad(sliderId){
  // unbindSliderEvents(sliderId);

  //  want the slider to be selected when the page loads
  $(sliderId).focus();

  // don't want users to be able to click or drag slider
  $(document).on('click', sliderId, function() {
    event.preventDefault();
  });

  $(document).on('mousedown', sliderId, function(event) {
   event.preventDefault();
 });

 $(document).on('mousedown', function(event) {
  event.preventDefault();
});
};

function recordSliderStartingPoint(last_trial, stimulus){
  const data = {
    response: SLIDE_START,
    rt: 0,
    slider_start: SLIDE_START,
    stimulus: stimulus,
    subject: last_trial['subject'],
    time_elapsed: jsPsych.totalTime(),
    expStartTime: jsPsych.startTime(),
    trial_index: last_trial['trial_index'] + 1,
    version: VERSION,
    trial_type: 'video-slider-response-response',
}
  onFinish(data);
}

function sliderOnStart(sliderId, stimulus){

  const last_trial =  jsPsych.data.getLastTrialData().values()[0];
  var start_time = new Date().getTime();


  // record the starting point of the slider before the trial begins!
  recordSliderStartingPoint(last_trial, stimulus);

  $(document).keydown(function(e) {
        var y = document.getElementById(sliderId.replace('#', ''));

        if ((e.which == 39) && (e.shiftKey)) {
          const oldVal = parseInt(y.value)
          var newVal = parseInt(y.value) + (SLIDE_BIG_STEP-1);
          if ((newVal + 1) >= SLIDE_MAX){
            newVal = SLIDE_MAX - 1;
          }
          y.value = newVal;
        }
        if ((e.which == 37) && (e.shiftKey)) {
          const oldVal = parseInt(y.value)
          var newVal = parseInt(y.value) - (SLIDE_BIG_STEP-1);
          if ((newVal - 1) <= SLIDE_MIN){
            newVal = SLIDE_MIN + 1;
          }
          y.value = newVal;
        }
  });

  $(document).on('change', sliderId, function() {
    var d = new Date();
    const diff =  d.getTime() - start_time;
    const data = {
      response: $(this).val(),
      rt: diff,
      slider_start: SLIDE_START,
      stimulus: stimulus,
      subject: last_trial['subject'],
      time_elapsed: jsPsych.totalTime(),
      expStartTime: jsPsych.startTime(),
      trial_index: last_trial['trial_index'] + 1,
      version: VERSION,
      trial_type: 'video-slider-response-response',
      trial_subtype: 'sliderRating_'+stimulus,

  }
    onFinish(data);
});
};

function getPreloadVideo1(){
  var video_list = ['static/videos/movieTP.mp4', 'static/videos/movieDM.mp4']

  var preload = {
    type: 'preload',
    error_message: 'The experiment failed to load - sorry about this! Please try moving to a better WIFI connection.',
    on_load: function(){
      $("#jspsych-loading-progress-bar-container").remove();

      $("#jspsych-content").prepend('<div id="load_gif_container" class="center"><img id="load_gif" src="static/images/load_small.gif" width="300" height="300"></div>');
       setTimeout(function(){  $("#load_gif_container").prepend(`
         <br><h3> Now loading your movie clips.</h3> <br>
         <br><h3> Loading will take about 1 minute, thank you for your patience!</a></h3></div>`) }, 5);


    },
    on_finish: function(){
       $("#load_gif").remove();

    },
    video: video_list,
      }
      return preload;
}

function getVideoPreloadProcedure(){
  var video_list = ['static/videos/movieFF.mp4']

  var preload = {
    type: 'preload',
    error_message: 'The experiment failed to load - sorry about this! Please try moving to a better WIFI connection.',
    on_load: function(){
      $("#jspsych-loading-progress-bar-container").remove();

      $("#jspsych-content").prepend('<div id="load_gif_container" class="center"><img id="load_gif" src="static/images/load_small.gif" width="300" height="300"></div>');
       setTimeout(function(){  $("#load_gif_container").prepend(`
         <br><h3> Now loading your movie clips.</h3> <br>
         <br><h3> Loading will take about 1 minute, thank you for your patience!</a></h3></div>`) }, 5);


    },
    on_finish: function(){
       $("#load_gif").remove();

    },
    video: video_list,
      }
      return preload;
}

function getEndProcedure(){
  const htmlStr = `<h1>Thanks for participating! </h1>`;
  return {
    on_load: function(){
      if (true) {
        $.ajax({
          type: "GET",
          contentType: "application/json; charset=utf-8",
          url: '/end',
          success: function(data){
            $("h1").append(`<br><br><br><br><br><h1>Please <a href="${data}">click here to finish the task</a>`);
          }
        });
      }
    },
    type: "html-keyboard-response",
    stimulus: htmlStr,
    choices: jsPsych.NO_KEYS,
  };
}

function onFinish(data){
  dm.recordData(data);
}

function getPreloadImagesProcedure(){
  return {
      type: 'preload',
      images: ['static/images/load_small.gif',
               'static/images/left_right_arrow.png',
               'static/images/movie.png'],}
}

function demographicsQuestions(){
  var DemoQ1_options = ["Male", "Female", "Gender Non-conforming", "Other", "Choose not to respond"];
  var DemoQ2_options = ["Under 18", "18-24", "25-34", "35-44", "45-54", "55-64", "65-74", "75-84", "85 or older"];
  var DemoQ3_options = ["Hispanic/Latino", "Not Hispanic/Latino", "Choose not to respond"];
  var DemoQ4_options = ["American Indian/Native American","White", "Black/African American", "Asian", "Native Hawaiian or Pacific Islander", "More than one race", "Other","Choose not to respond"];
  var DemoQ5_options = ["Less than a high school diploma", "High school degree or equivalent (e.g. GED)", "Some college, no degree", "Associate degree (e.g. AA, AS)", "College degree", "Master's degree (e.g. MA, MS, MEd)", "Doctorate or professional degree (e.g. MD, DDS, PhD)"];

  var all_that_apply = {type: 'survey-multi-select',
      questions: [
        {
          prompt: "How would you describe yourself? Please select all that apply.",
          options: DemoQ4_options,
          horizontal: false,
          required: true,
          name: 'DemoQ4'
        },]
      };
  var multi_choice_Demo = {
      type: 'survey-multi-choice',
      button_label: 'Next',
      preamble: 'Please answer some further questions on demographics.',
      questions: [
          { prompt: "What is your gender?", name: 'DemoQ1', options: DemoQ1_options, required: true },
          { prompt: "What is your age?", name: 'DemoQ2', options: DemoQ2_options, required: true },
          { prompt: "What is your Ethnicity?", name: 'DemoQ3', options: DemoQ3_options, required: true },
          { prompt: "What is the highest degree or level of school you have completed?", name: 'DemoQ5', options: DemoQ5_options, required: true },
      ],
  };
  return  {timeline:  [multi_choice_Demo, all_that_apply]};
}
