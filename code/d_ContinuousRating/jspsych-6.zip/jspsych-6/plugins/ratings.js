/*
 * Example plugin template
 */

jsPsych.plugins["ratings"] = (function() {

  var plugin = {};

  plugin.info = {
    name: "ratings",
    parameters: {
      canvas_size: {
        type: jsPsych.plugins.parameterType.IMAGE,
        pretty_name: 'Canvas dimensions',
        array: true,
        default: [1920, 1080],
        description: 'Size of canvas'
      },
    }
  }

  plugin.trial = function(display_element, trial) {

    display_element.innerHTML = "<div style='align:center; margin:0; cursor:url(dot.png) 12 12 ,pointer'>"+"<canvas id='myCanvas' width='"+trial.canvas_size[0]+"' height='"+trial.canvas_size[1]+"'></canvas>"+"</div>"
      
    function clearscreen(){
        ctx.clearRect(0, 0, trial.canvas_size[0], trial.canvas_size[1]);
    }
    
      
    var x_center = trial.canvas_size[0]/2;
    var y_center = trial.canvas_size[1]/2;
    var radius = 12;
    var side_length = 500;


    var c = document.getElementById("myCanvas");
    var ctx = c.getContext("2d");
    var line1 = c.getContext("2d");
    var line2 = c.getContext("2d");
    var BigGrid  = c.getContext("2d");


    function DrawBigGrid(){

        /* draw a rect*/
        BigGrid.beginPath();
        BigGrid.rect(x_center-side_length/2, y_center-side_length/2, side_length, side_length);
        BigGrid.stroke();
        BigGrid.closePath();

    }

    function DrawLine1(){

        /* draw vertical lines*/
        line1.beginPath();
        line1.moveTo(x_center,y_center-side_length/2);
        line1.lineTo(x_center,y_center+side_length/2);
        line1.strokeStyle = 'red';
        line1.stroke();
    }

    function DrawLine2(){

        /* draw horizontal lines*/
        line2.beginPath();
        line2.moveTo(x_center-side_length/2,y_center);
        line2.lineTo(x_center+side_length/2,y_center);
        line2.strokeStyle = 'blue';
        line2.stroke();
    }
    
    var k = 0;
    var dot = c.getContext("2d");

    function Drawdot(x,y){
        dot.beginPath();
        dot.arc(x, y, radius, 0, 2 * Math.PI);
        dot.strokeStyle = 'black';
        dot.stroke()
        dot.closePath();
        k = k + 1;
    }

    function getMousePos(canvas, evt)
    {
        var rect = canvas.getBoundingClientRect();
        return {
            x: evt.clientX - rect.left,
            y: evt.clientY - rect.top
        };
    };
    
    c.addEventListener("click", click_event);
    
    function click_event(evt){
        var mousePos = getMousePos(c, evt);
        var x_dis = Math.abs(mousePos.x-x_center);
        var y_dis = Math.abs(mousePos.y-y_center);
        if (k < 1 && x_dis < side_length/2 && y_dis < side_length/2){
            Drawdot(mousePos.x, mousePos.y);
        }
        if (k >= 1){
            c.removeEventListener("click",click_event);
            setTimeout(end_trial,750);
        }
    };
    
    function fillTextRotated(text, x, y, color, angle) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.textAlign = "center";
        ctx.fillStyle = color;
        ctx.fillText(text, 0, 0);
        ctx.restore();
     }
    
    DrawBigGrid();
    DrawLine1();
    DrawLine2();

    var notes = c.getContext("2d");
    notes.font = "20px Georgia";
    notes.fillStyle = "black";
    notes.textAlign = "center";
    notes.fillText("Please rate your valence and arousal",trial.canvas_size[0]/2,(trial.canvas_size[1]/2-side_length/2)/2);

    var high_arousal = c.getContext("2d");
    high_arousal.font = "20px Georgia";
    high_arousal.fillStyle = "red";
    high_arousal.textAlign = "center";
    high_arousal.fillText("High Arousal",trial.canvas_size[0]/2,trial.canvas_size[1]/2-side_length/2-10);

    var low_arousal = c.getContext("2d");
    low_arousal.font = "20px Georgia";
    low_arousal.fillStyle = "red";
    low_arousal.textAlign = "center";
    low_arousal.fillText("Low Arousal",trial.canvas_size[0]/2,trial.canvas_size[1]/2+side_length/2+20);

    fillTextRotated("Unpleasant", x_center - side_length/2 - 15, y_center, "blue", -Math.PI/2); 
    fillTextRotated("Pleasant", x_center + side_length/2 + 15, y_center, "blue", Math.PI/2); 
    
    function end_trial(){
      // end trial
      jsPsych.finishTrial();
    };
  };

  return plugin;
})();
