
function getVideoProcedure(){

  var stimulus = `segment1.mp4`;

  var trial = {
  type: "video-slider-response",
  stimulus: [stimulus],
  width: 600,
  height: 400,
  slider_width: SLIDE_WIDTH,
  trial_ends_after_video: true,
  slider_start: SLIDE_START,
  button_label: '',
  min: SLIDE_MIN,
  max: SLIDE_MAX,
  step: 1,
  post_trial_gap: 200,
  on_load: function(){
    sliderOnLoad('#jspsych-video-slider-response-response')
  },
  labels: SLIDE_LABELS,
  on_finish: function(data) {
    sliderOnFinish('#jspsych-video-slider-response-response');
    data.trial_subtype = 'sliderRating';
  },
  on_start: function(trial) {
    $('#jspsych-video-slider-response-next').hide();
    $('#jspsych-video-slider-response-next').css("visibility", "hidden");

    const sliderId = '#jspsych-video-slider-response-response';
    sliderOnStart(sliderId, stimulus);
  },
  }
  return trial;
}
